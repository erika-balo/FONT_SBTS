export const environment = {
    production: true,
    API_URL: 'https://api.subastaugrch.com',
    MERCURE_URL: 'https://mercure.subastaugrch.com/.well-known/mercure',
    URL_IMAGENES: 'http://54.202.160.216',
};
