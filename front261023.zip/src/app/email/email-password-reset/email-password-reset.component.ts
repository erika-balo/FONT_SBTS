import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-password-reset',
  templateUrl: './email-password-reset.component.html',
  styleUrls: ['./email-password-reset.component.css']
})
export class EmailPasswordResetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
